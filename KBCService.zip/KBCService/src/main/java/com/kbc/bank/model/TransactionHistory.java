package com.kbc.bank.model;
import java.util.Date;


public class TransactionHistory {
	
	
	private Long accountNo;
	private Date transactionDate;
	private String transactionDetails;
	
	
	public TransactionHistory(Long acNo) {
		this.accountNo = acNo;
		this.transactionDate = new Date();
	}
	
	public TransactionHistory(Long acNo,String transDetails) {
		this.accountNo = acNo;
		this.transactionDate = new Date();
		this.transactionDetails = transDetails;
	}
	
	
	public Long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getTransactionDetails() {
		return transactionDetails;
	}
	public void setTransactionDetails(String transactionDetails) {
		this.transactionDetails = transactionDetails;
	}
	
	
	

}
