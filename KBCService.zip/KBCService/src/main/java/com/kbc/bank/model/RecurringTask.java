package com.kbc.bank.model;


import java.util.Date;
import java.util.TimerTask;

import org.springframework.beans.factory.annotation.Autowired;

public class RecurringTask extends TimerTask {

	@Autowired
	private BankAppDao bankAppDao;
    @Override
    public void run() {
        System.out.println("Timer task started at:"+new Date());
        bankAppDao.startRecurringTask();
        System.out.println("Timer task finished at:"+new Date());
    }

   
    
    

}