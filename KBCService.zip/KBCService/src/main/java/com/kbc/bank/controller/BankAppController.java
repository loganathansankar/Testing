package com.kbc.bank.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.kbc.bank.model.BankAppService;

@RestController
public class BankAppController {
	
	@Autowired
	private BankAppService service;
	
	@RequestMapping(value = "/BankApp/createAccount/{cusName}/{initialBal}", 
			method = RequestMethod.POST, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Long> createNewAccount(@PathVariable("cusName") String cusName,@PathVariable("initialBal") Double initialBal){
		
		Long accNo = service.createNewAccount(cusName, initialBal);
		
		return new ResponseEntity<Long>(accNo,HttpStatus.CREATED);
	}
	
	
	@RequestMapping(value = "/BankApp/showBalance/{accNo}", 
			method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Double> showAccountBalance(@PathVariable("accNo") Long accNo) {
		
		Double balance = 0.0d;
		
		try {
			balance = service.showAccountBalance(accNo);
			
		} catch(Exception exception) {
			
			return new ResponseEntity<Double>(balance, HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Double>(balance, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/BankApp/transferPayment/{frmAccNo}/{toAccNo}/{transAmt}/{isRecurring}", 
			method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Void> transferPayment(@PathVariable("frmAccNo") Long frmAccNo,
			@PathVariable("toAccNo") Long toAccNo,@PathVariable("transAmt") Double transAmt,
			@PathVariable("isRecurring") Integer isRecurring) {
		
		try {
			
			final Boolean isTransferd = service.transferPayment(frmAccNo, toAccNo, transAmt,isRecurring);
			
			if(!isTransferd) {
				
				return new ResponseEntity<Void>(HttpStatus.EXPECTATION_FAILED);
			}
			
		} catch (Exception e) {
			
			return new ResponseEntity<Void>(HttpStatus.EXPECTATION_FAILED);
		}
		
		
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
	@RequestMapping(value = "/BankApp/transactionHisory/{accNo}/{fromDate}/toDate/", 
			method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<String>> showTransactionHistory(@PathVariable("accNo") Long accNo,
			@PathVariable("fromDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date fromDate,
			@PathVariable("toDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date toDate) {
		
		
		try {
			
			final List<String> historyDetail = service.showAllTransaction(accNo, fromDate, toDate);
			
			if(null != historyDetail && !historyDetail.isEmpty()) {
			
				return new ResponseEntity<List<String>>(historyDetail,HttpStatus.OK);
			}
			
		} catch (Exception e) {
			return new ResponseEntity<List<String>>(HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<String>>(HttpStatus.NOT_FOUND);
	}
	

}
