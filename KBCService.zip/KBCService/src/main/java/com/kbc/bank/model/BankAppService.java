package com.kbc.bank.model;
import java.util.Date;
import java.util.List;


public interface BankAppService {

	Long createNewAccount( String cusName, Double initialBal);
	
	Double showAccountBalance(Long accNo);
	
	Boolean transferPayment(Long fromAcc,Long toAcc,double transAmt,Integer isRecurring);
	
	List<String> showAllTransaction(Long accNo,Date fromDate,Date toDate);
}
