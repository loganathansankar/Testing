package com.kbc.bank;


import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication 
public class SpringBootBankApp {

	public static void main(String[] args) {
	
	  TimerTask timerTask = new RecurringTask();
		 
		 Calendar today = Calendar.getInstance();
		 today.set(Calendar.HOUR_OF_DAY, 2);
		 today.set(Calendar.MINUTE, 0);
		 today.set(Calendar.SECOND, 0);
		 Timer timer = new Timer(true);
	     timer.schedule(timerTask, today.getTime(), TimeUnit.MILLISECONDS.convert(1, TimeUnit.DAYS));
		 
		SpringApplication.run(SpringBootBankApp.class, args);
	}
}
