package com.kbc.bank.model;

public class RecurringAccount {

	private Long fromAcc;
	private Long toAcc;
	private Double transAmt;
	
	
	public RecurringAccount(Long fromAcc,Long toAcc,Double transAmt) {
		
		this.fromAcc = fromAcc;
		this.toAcc = toAcc;
		this.transAmt = transAmt;
	}
	
	public Long getFromAcc() {
		return fromAcc;
	}
	public void setFromAcc(Long fromAcc) {
		this.fromAcc = fromAcc;
	}
	public Long getToAcc() {
		return toAcc;
	}
	public void setToAcc(Long toAcc) {
		this.toAcc = toAcc;
	}
	public Double getTransAmt() {
		return transAmt;
	}
	public void setTransAmt(Double transAmt) {
		this.transAmt = transAmt;
	}
	
	
}
