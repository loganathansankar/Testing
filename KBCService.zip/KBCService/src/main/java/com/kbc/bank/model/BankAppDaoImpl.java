package com.kbc.bank.model;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

/*
 * This class used to manage account and transaction history details
 */
@Service
public class BankAppDaoImpl implements BankAppDao {
	
	
	private static Long accountNo = 000000000L;
	
	private static final Map<Long, BankAccount> accountMap = new HashMap<Long, BankAccount>();
	
	private static final Map<Long, RecurringAccount> recurringMap = new HashMap<Long, RecurringAccount>();
	
	private static final Map<Long,List<TransactionHistory>> transHistoryMap = new HashMap<Long, List<TransactionHistory>>();
	
	
	
	public Long createNewAccount(final String cusName,final Double initialBal) {
		
		Long cusAccNo =  accountNo;
		
		cusAccNo++;
		
		BankAccount account = new BankAccount(cusAccNo, cusName, initialBal);
		
		accountMap.put(cusAccNo, account);
		
		
		accountNo++;
		
		return cusAccNo;
	}
	
	
	
	public  void updateAccount(final BankAccount account) {
		
		accountMap.put(account.getAccountNo(), account);
	}
	
	
	
	public BankAccount findAccount(final Long accNo) {
		
		if(!accountMap.containsKey(accNo)) {
			
			throw new RuntimeException("Invalid bank account");
		}
		
		return accountMap.get(accNo);
	}
	
	/**
	 * Keep track transaction history
	 * @param accNo
	 * @param transDetail
	 */
	public void saveOrUpdateTransHistroy(final Long accNo,final String transDetail) {
		
		if( null != transHistoryMap.get(accNo)) { // has transaction for given account number
			
			
			List<TransactionHistory> transHistoryLisy = transHistoryMap.get(accNo);
			TransactionHistory  history = new TransactionHistory(accNo, transDetail);
			transHistoryLisy.add(history);
			
		} else {
			
			// if transaction history not there then create one.
		
			List<TransactionHistory> transHistoryLisy = new ArrayList<TransactionHistory>();
			TransactionHistory  history = new TransactionHistory(accNo, transDetail);
			transHistoryLisy.add(history);
			transHistoryMap.put(accNo, transHistoryLisy);
		}
		
	}
	
	public List<TransactionHistory> getTransactionHistroy(final Long accNo) {
		
		if(null == transHistoryMap.get(accNo)) {
			
			throw new RuntimeException("Account not found");
		}
		
		return transHistoryMap.get(accNo);
	}
	
	public void setupRecurringTask(final Long frmAccNo,final Long toAccNo,final Double transAmt) {
		
		RecurringAccount account = new RecurringAccount(frmAccNo,toAccNo,transAmt);
		
		recurringMap.put(frmAccNo, account);
		
	}
	
	public void startRecurringTask() {
		
		
		for(Map.Entry<Long, RecurringAccount> entryMap:recurringMap.entrySet()) {
			
			RecurringAccount account = entryMap.getValue();
			
			BankAccount fromAccount = findAccount(account.getFromAcc());
			BankAccount toAccount = findAccount(account.getToAcc());
			
			
			if(fromAccount.getBalance() >= account.getTransAmt() ) {
				
			
			fromAccount.setBalance(fromAccount.getBalance() - account.getTransAmt());
			toAccount.setBalance(toAccount.getBalance() + account.getTransAmt() );
			
			updateAccount(fromAccount);
			updateAccount(toAccount);
			
			
			saveOrUpdateTransHistroy(account.getFromAcc(), MessageFormat.format("Amount:{0} Transferd to account no {1}", account.getTransAmt(),account.getToAcc()));
			saveOrUpdateTransHistroy(account.getToAcc(), MessageFormat.format("Amount:{0} Transferd from  account no {1}", account.getTransAmt(),account.getFromAcc()));

		  }
			
		}
		
		
	}

}
