package com.kbc.bank.model;

public class BankAccount {

	private Long accountNo;
	private String customerName;
	private Double balance = 0d;
	
	public BankAccount(Long acNo,String cusName,Double initialBal) {
		this.accountNo = acNo;
		this.customerName = cusName;
		this.balance = initialBal;
	}
	
	

	public Long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}
	
}
