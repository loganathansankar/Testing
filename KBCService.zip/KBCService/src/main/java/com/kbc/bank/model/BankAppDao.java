package com.kbc.bank.model;

import java.util.List;


public interface BankAppDao {

	
	Long createNewAccount(String cusName,Double initialBal);
	
	BankAccount findAccount(Long accNo);
	
	void updateAccount(BankAccount account);
	
	void saveOrUpdateTransHistroy(Long accNo,String transDetail);
	
	List<TransactionHistory> getTransactionHistroy(Long accNo);
	
	void startRecurringTask();
	
	void setupRecurringTask(Long frmAccNo,Long toAccNo,Double transAmt);
}
