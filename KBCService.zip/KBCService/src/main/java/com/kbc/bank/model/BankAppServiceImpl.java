package com.kbc.bank.model;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class BankAppServiceImpl implements BankAppService{
	
	@Autowired
	private BankAppDao dao;
	
	
	public Long  createNewAccount(final String cusName,final Double initialBal) {
		
		return dao.createNewAccount(cusName, initialBal);
		
		
	}
	
	public Double showAccountBalance(final Long accNo)  {
		
		
		BankAccount account = dao.findAccount(accNo);
		
		return account.getBalance();
		
	}
	
	/**
	 * Transfer amount from account - to account
	 */
	public Boolean transferPayment(final Long fromAcc,final Long toAcc,final double transAmt,final Integer isRecurring) {
		
		try {

			BankAccount fromAccount = dao.findAccount(fromAcc);
			BankAccount toAccount = dao.findAccount(toAcc);
			
			
			if(fromAccount.getBalance() < transAmt ) {
				
				return  false;
			}
			
			fromAccount.setBalance(fromAccount.getBalance() - transAmt);
			toAccount.setBalance(toAccount.getBalance() + transAmt );
			
			dao.updateAccount(fromAccount);
			dao.updateAccount(toAccount);
			
			
			dao.saveOrUpdateTransHistroy(fromAcc, MessageFormat.format("Amount:{0} Transferd to account no {1}", transAmt,toAcc));
			dao.saveOrUpdateTransHistroy(toAcc, MessageFormat.format("Amount:{0} Transferd from  account no {1}", transAmt,fromAcc));
			
			if(isRecurring == 1) {
				dao.setupRecurringTask(fromAcc, toAcc, transAmt);
			}

		} catch (Exception e) {
			throw new RuntimeException("Error while transferPayment");
		}
		
		return true;
	}
	
	public List<String> showAllTransaction(final Long accNo,final Date fromDate,final Date toDate) {
		
		final List<String> historyList = new ArrayList<String>();
		
		List<TransactionHistory> transList = dao.getTransactionHistroy(accNo);
		
		if(null != transList) {
			
			for(TransactionHistory history:transList) {
				
				if(history.getTransactionDate().after(fromDate) 
						&& history.getTransactionDate().before(toDate)) {
					
					historyList.add(history.getTransactionDetails());
					
				}
			}
		}
		
		
		return historyList;
	}

}
